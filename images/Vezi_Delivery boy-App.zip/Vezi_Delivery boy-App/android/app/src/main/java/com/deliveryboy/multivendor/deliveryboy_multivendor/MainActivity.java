package com.vezi.driver;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
