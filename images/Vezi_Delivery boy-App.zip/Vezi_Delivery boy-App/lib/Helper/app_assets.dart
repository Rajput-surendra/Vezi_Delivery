class Myassets {
  static const String app_logo = 'assets/logo/normal_logo.png';
  static const String login_logo = 'assets/logo/login_logo.png';
  static const String loding_logo = 'assets/logo/slider_loding.png';
  static const String loding_logo_bg = 'assets/logo/slider_loding.png';
}
